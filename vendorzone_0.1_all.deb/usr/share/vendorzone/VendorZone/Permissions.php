<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SysPermissions.
 *
 * @author vitex
 */
namespace VendorZone;

class Permissions
{
    public static $rights = ['invoice', 'cash'];
}
