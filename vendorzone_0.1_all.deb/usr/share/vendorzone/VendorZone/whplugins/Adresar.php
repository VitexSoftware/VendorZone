<?php
namespace VendorZone\whplugins;

/**
 * Description of Adresar
 *
 * @author vitex
 */
class Adresar extends \VendorZone\WebHookHandler
{
    //put your code here
}
