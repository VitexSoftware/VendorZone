<?php

namespace VendorZone\whplugins;

/**
 * Description of Kontakt
 *
 * @author vitex
 */
class Kontakt extends \VendorZone\WebHookHandler
{
    //put your code here
}
