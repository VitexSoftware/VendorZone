<?php

/**
 * Třída správy skupin firem.
 *
 * @author vitex
 */
namespace VendorZone;

class SkupinaFirem extends Importer\Importer
{
    public $evidence = 'skupina-firem';
}
